{
	daemons:[],
	
	services: {
		"helloworld": {
			description: "hello world 示例",
			class: "tutorial.HelloWorldService"
		}
	},

	filtersDescripton: "'*' will filter all key(cmd) and others match the exact key(cmd)",
	filters: {
		"*":["tutorial.CommonFilter"]
	}
}
