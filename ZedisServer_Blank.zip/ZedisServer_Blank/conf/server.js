{
	name: "ZedisServer",
	version: "1.6.2",
	port: 9527,
	
	webServer: true,
	webServerPort: 2012,

	useCachedThreadPool: true,	
	threadNum: -1,
	accessLog: true,
	basicCommandLog: false,
	slowServiceMilliSecond: 3000L,

	serverExceptionToClient: 1
}	
