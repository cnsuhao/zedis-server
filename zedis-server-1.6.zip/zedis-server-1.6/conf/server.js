{
	name: "ZedisServer",
	version: "1.6.1",
	port: 9527,
	
	webServer: true,
	webServerPort: 2012,
	
	useCachedThreadPool: true,
	threadNum: -1,
	
	accessLog: true,
	basicCommandLog: false,
	slowServiceMilliSecond: 1000L,
	
	serverExceptionToClient: 1,

	note: "daemons, services, filters can alse in the file, but i recommend you put then in the conf/service.js file"
}