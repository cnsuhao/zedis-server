package tutorial;

import java.io.UnsupportedEncodingException;

import zedis.server.framework.AbstractService;
import zedis.server.framework.Result;

public class HelloWorldService extends AbstractService {

	@Override
	public Result get(String key) {
		return new Result(Result.SUCCESS, "hello world !");
	}

	@Override
	public Result set(String key, byte[] value) {
		String content;
		try {
			content = new String(value, "utf-8");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
			throw new RuntimeException(e.getMessage());
		}
		return new Result(Result.SUCCESS, "you send '" + content + "' to me");
	}

	
	
}
