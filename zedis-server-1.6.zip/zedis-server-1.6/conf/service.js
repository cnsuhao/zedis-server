{
	daemons:["example.CacheTaskDealSampleDaemon"],
	
	services: {
		sample: {
			description: "sample service",
			class: "example.SampleService",
		},
		benchmark_test: {
			description: "benchmark test",
			class: "benchmark.BenchmarkTestService",
		}
	},

	filters: {
		"*":["example.CommonFilter"],
		"sample":["example.CommonFilter","example.CommonFilter"]
	}
}