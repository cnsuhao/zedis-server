#!/bin/bash

classpath="bin"

#basic lib
for jar in `ls lib`
do
    classpath=$classpath:lib/$jar
done
#servlet lib
for jar in `ls lib/jetty`
do
    classpath=$classpath:lib/jetty/$jar
done

java -cp $classpath zedis.server.ZedisServer
