#!/bin/bash

currentDir=`pwd`
baseDirForScriptSelf=$(cd "$(dirname "$0")"; pwd)
cd $baseDirForScriptSelf
cd ..

classpath="bin"
pidfile="logs/zedis-pid.txt"

#basic lib
for jar in `ls lib`
do
    classpath=$classpath:lib/$jar
done
#servlet lib
for jar in `ls lib/jetty`
do
    classpath=$classpath:lib/jetty/$jar
done

APP_PATH_INFO="-Dzedis.base=$baseDirForScriptSelf"
HEAP_OPTS="-Xmx128m -Xms8m -XX:NewSize=26m -XX:CMSFullGCsBeforeCompaction=5 -XX:+UseCMSCompactAtFullCollection"
GC_OPTS="-XX:+UseConcMarkSweepGC -XX:+UseParNewGC"
JAVA_OPTS="-server $GC_OPTS $HEAP_OPTS $APP_PATH_INFO"


case "$1" in

  start)
    echo "starting zedis server..."
    if [ -f "$pidfile" ] ; then
      echo "zedis is running or shutdown unnormal"
      cd $currentDir
      exit 1     
    fi
    sh -c "echo "'$$'" > $pidfile; exec ${JAVA_HOME}/bin/java ${JAVA_OPTS} -cp $classpath zedis.server.ZedisServer" & disown %- 
  ;;

  stop)
    echo "shutdown zedis server..."
    if [ -f "$pidfile" ] ; then
      kill `cat $pidfile`
      rm -rf $pidfile
    else
      echo "zedis is not running"
    fi
  ;;

  *)
    echo "./scripts/startup.sh {start|stop}"
    cd $currentDir
    exit 1
  ;;

esac

cd $currentDir
exit 0
