package tool;

import zedis.server.ZedisServer;

/** 
 * develop server start helper class
 * @author ytzhang0828@gmail.com
 */
public class ZedisBootstrap {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
        new ZedisServer().run();
	}

}
