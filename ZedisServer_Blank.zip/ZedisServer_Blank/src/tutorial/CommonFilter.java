package tutorial;

import zedis.server.framework.AbstractFilter;

public class CommonFilter extends AbstractFilter {

	//you can filter here
	
}
